from django.shortcuts import render
from django.http import HttpResponse

# Create your views here. Python Functions
def inde(request):
    
    return render(request, 'inde.html')

def register(request):
    
     return render(request, 'register.html')

def login(request):
    return render(request, 'login.html')

def home(request):
    return render(request, 'home.html')

def cars(request):
    return render(request, 'cars.html')

def contact(request):
    return render(request, 'contact.html')
     