from django.contrib import admin
from django.urls import include,path
from car import views

urlpatterns = [
    
     path('login/', views.login, name='login'),
     path('register/', views.register, name='register'),
    path('inde/',views.inde,name="inde"),
    path('home/',views.home,name="home"),
    path('cars/',views.cars,name="cars"),
    path('contact/',views.contact,name="contact"),
    
]