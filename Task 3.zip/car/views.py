from django.shortcuts import render,redirect
# from django.http import HttpResponse
from django.contrib.auth.models import User 
from django.contrib import auth
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from .models import Car,Contact




# Create your views here. Python Functions
def inde(request):
    
    return render(request, 'inde.html')

def register(request):
    
    if request.method == 'POST':
        first_name = request.POST['fname']
        last_name = request.POST['lname']
        username=request.POST['uname']
        email= request.POST['email']
        password = request.POST['pass1']
        confirm_password = request.POST['pass2']
        
        if password == confirm_password:
            if User.objects.filter(email=email).exists():
                print('Email is already taken')
                return redirect('register')
            elif User.objects.filter(username=username).exists():
                print('Username is already taken')
                return redirect('register')
            else:
                user = User.objects.create_user(username=username, password=password, email=email, first_name=first_name, last_name=last_name)
                user.save()
                print('User created')
                return redirect('login')
             
        else:
            mesaages.info(request, 'Password not matching')
            return render(request, 'register.html')
         
    
    return render(request, 'register.html')

# def login(request):
#     if request.method == 'POST':
#         email = request.POST['email']
#         password = request.POST['password']
#         user = authenticate(email=email , password=password)
        
#         if user is not None:
#             auth.login(request, user)
#             messages.success(request, 'Login successful.')
#             return redirect('home')
#         else:
#             messages.info(request, 'Invalid credentials')
#             return redirect('login')
#     else:       
#         return render(request, 'login.html')

def user_login(request):
    if request.method == 'POST':
        username = request.POST["username"]
        password = request.POST["password"]

        user = authenticate(username=username, password=password)
        if user is not None:
            
            login(request, user)  # Renamed the login function to auth_login
            return redirect("home")
        else:
            messages.error(request, "Invalid username or password")
            return redirect("login")

    return render(request, "login.html")
    

def logout(request):
    auth.logout(request)
    return redirect('login')

 
def home(request):
    return render(request, 'home.html')

def cars(request):
    car=Car.objects.all()
    params={'car':car}
    return render(request, 'cars.html',params)

def contact(request):
    if request.method=="POST":
        conname=request.POST['fullname']
        conemail=request.POST['email']
        conphone=request.POST['phone']
        conmessage=request.POST['message'] 
        contact = Contact(name = conname, email = conemail, phone_number = conphone,message = conmessage)
        contact.save()    
    
        
    return render(request, 'contact.html')

def rent(request):
    
     
    
    return render(request, 'rent.html')

def payment(request):
    return render(request, 'payment.html')

def about(request):
    return render(request, 'about.html')

def payconf(request):
    return render(request, 'payconf.html')

def profile(request):
    return render(request, 'profile.html')
     